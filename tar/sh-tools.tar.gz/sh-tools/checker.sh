#!/bin/bash
trap 'interruptProcess; exit 1' SIGINT SIGTERM
function main() {
    echo "main begin"
    echo $0 $*
    sleep 10
    echo "main finish"
}

function interruptProcess() {
    echo -e "\ninterrupt process begin"
    echo "interrupt process finish"
}

main $* 

