#!/bin/bash
cd ${0%/*}

for item in $(cat docker-images.conf)
do
  docker pull ${item}
done
