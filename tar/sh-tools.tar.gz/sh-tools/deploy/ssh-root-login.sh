#!/bin/bash
sshdConfigFile=/etc/ssh/sshd_config
configItem=$(cat ${sshdConfigFile} | grep ^PermitRootLogin)
echo ${configItem}
if [ "${configItem#* }" == "without-password" ]; then
  sed -i 's/^PermitRootLogin without-password/PermitRootLogin yes/g' ${sshdConfigFile}
  echo "update config item"
  cat ${sshdConfigFile} | grep ^PermitRootLogin
  echo "ssh service restart"
  service ssh restart
else
  echo "no need to update config item"
fi
exit 0
