#!/bin/bash
trap 'taskClean; exit' SIGINT SIGTERM

function taskOne() {
   echo "Now do task one..."
   sleep 10
   echo "TaskOne is done"
}
 
function taskTwo() {
   echo "Now do task two..."
   sleep 10
   echo "TaskTwo is done"
}

function taskClean() {
    echo "clean task"
} 

taskOne
taskTwo
