#! /bin/bash
ssh root@sublime "/root/bin/jenkins_start.sh"

