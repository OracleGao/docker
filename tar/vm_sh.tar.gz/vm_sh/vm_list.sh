#! /bin/bash
vmrun list
echo "--------------------------------------"
echo "Total VMs:"
ls -lR /home/pc/vmware/*/*.vmx | awk -F ' ' '{print $9}'
