#!/bin/bash

cd ${0%/*}

if [ $# -lt 1 ]; then
    echo "Usage $0 <vm name>"
    exit 1
fi
vmrun -T ws start /home/pc/vmware/$1/$1.vmx nogui 
