#!/bin/bash
cd ${0%/*}

imagesPath=images
pullPath=pull-images
pullImageFile=${pullPath}/pull-images.conf
: > ${pullImageFile}
for item in $(cat registory-images.conf)
do
  dev=${item//_/\/}
  dev=${dev//+/:}
  dev=${dev%.dif}
  kmx=${dev/dev/kmx}
  kmx=${kmx/5001/5000}
  docker load -i ${imagesPath}/${item}
  docker tag ${dev} ${kmx}
  docker rmi ${dev}
  docker push ${kmx}
  echo ${kmx} >> ${pullImageFile}
done
