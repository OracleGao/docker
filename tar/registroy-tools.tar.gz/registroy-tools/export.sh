#!/bin/bash

cd ${0%/*}

exportConfigFile=images-export.cfg
replaceConfigFile=replace.cfg
imagePath=images
suffix=.dif
importConfigFile=images-import.cfg

function getFilename(){
  imageName=$1
  filename=${imageName}
  IFS_BAK=${IFS}
  for item in $(cat ${replaceConfigFile})
  do
    IFS=','
    kv=(${item})
    filename=${filename//${kv[0]}/${kv[1]}}
  done
  IFS=${IFS_BAK}
  echo ${filename}${suffix}
}

mkdir -p ${imagePath}

: > ${importConfigFile}
for item in $(cat ${exportConfigFile})
do
  filename=$(getFilename ${item})
  echo "pull image [${item}]"
  docker pull ${item}
  echo "export image [${item}]"
  docker save -o ${imagePath}/${filename} ${item}
  echo ${filename} >> ${importConfigFile}
  echo "export image [${item}] success"
done
