#!/bin/bash
cd ${0%/*}

if [ "$#" -lt 1 ]; then
  echo "Usage $0 <path> [output] [cpu cores]"
  exit 1
fi

name=$(basename $1)
path="$(dirname $1)/${name}"
outputPath=${2:-output}
outputPath="${outputPath}/${name}"

cpuCores=${3:-8}

mkdir -p ${outputPath}

for item in $(ls ${path}); do
  tar cf - -C ${path} ${item} | pigz -0 -p ${cpuCores} > ${outputPath}/${item##*/}.tar.gz
done

exit 0
