#!/bin/bash
cd ${0%/*}

if [ "$#" -lt 1 ]; then
    echo "Usage $0 <path> [output] [cp | mv]"
    exit 1
fi

fileSubffix=.goldwind

name=$(basename $1)

outputPath=${2:-output}
outputPath="${outputPath}/${name}"
cmd=${3:-cp}

mkdir -p ${outputPath}

for item in $(find $1 -name "*${fileSubffix}"); do
    file=${item}
    item=${item##*/}
    pathTemp="${outputPath}/${item:0:14}"
    mkdir -p ${pathTemp}
    ${cmd} ${file} ${pathTemp}/.
done

