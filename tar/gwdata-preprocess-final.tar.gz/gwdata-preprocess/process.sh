#!/bin/bash
cd ${0%/*}

level=info

which pigz >> /dev/null
if [ $? -ne 0 ]; then
  source utils/shell/logs.sh
  setLogLevel ${level}
  logWarning "pigz not found"
  logInfo "begin to install pigz"
  logCmd "apt-get update"
  apt-get update
  logCmd "apt-get install -y pigz"
  apt-get install -y pigz
  if [ $? -ne 0 ]; then
    logError "pigz install error"
    exit 1
  else
    logInfo "pigz install success"
  fi
fi
version=1.0.2
if [ $# -lt 1 ]; then
  echo "data preprocess version: ${version}"
  echo "Usage $0 <path> [cp | mv] [output] [cpu cores]"
  exit 1
fi

type setLogLevel 2>&1 >> /dev/null
if [ $? -ne 0 ]; then
  source utils/shell/logs.sh
  setLogLevel ${level}
fi

currPath="$(pwd)"

cmd=${2:-cp}

output=${3:-output}
mkdir -p ${output}
cd ${output}
output="$(pwd)"
cleaningOutput=${output}/cleaning
packagingOutput=${output}/packaging
cd ${currPath}

cpuCores=${4:-8}

logFile=finish.log

name=$(basename $1)
path="$(dirname $1)/${name}"

cd ${path}
path="$(pwd)"
cd ${currPath}

mkdir -p ${cleaningOutput}
mkdir -p ${packagingOutput}

logInfo "begin to process"
for item in $(ls ${path}); do
  logInfo "begin to cleaning ${item}"
  logCmd "cleaning/cleaning.sh ${path}/${item} ${cleaningOutput} ${cmd}"
  cleaning/cleaning.sh ${path}/${item} ${cleaningOutput} ${cmd}
  if [ $? -ne 0 ]; then
    logError "cleaning ${item} failed"
    exit 1
  else
    logInfo "cleaning ${item} success"
  fi
  logInfo "begin to packaging ${item}"
  logCmd "packaging/packaging.sh ${cleaningOutput}/${item} ${packagingOutput} ${cpuCores}"
  packaging/packaging.sh ${cleaningOutput}/${item} ${packagingOutput} ${cpuCores}
  if [ $? -ne 0 ]; then
    logError "packaging ${item} failed"
    exit 1
  else
    logInfo "packaging ${item} success"
  fi
done
logInfo "process success"

