#!/bin/bash
cd ${0%/*}

if [ $# -lt 1 ]; then
    echo "Usage $0 <path>"
    exit 1
fi

logFile=out.log

./process.sh $1 mv > ${logFile} 2>&1 &

