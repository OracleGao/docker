logLevel=5 ##debug:5, info:4, warning:3, error:2

function setLogLevel() {
  case $1 in
    error) logLevel=2 ;;
    warning) logLevel=3 ;;
    info) logLevel=4 ;;
    debug) logLevel=5 ;;
    *) 
      local logLevelTmp=${level}
      logLevel=3
      logWarning "invalidate log level [$1], choose from [debug | info | warning | error]"
      logLevel=${levelTmp}
      return;
  esac
  logInfo "set log level [$1]"
}

function logError() {
  if [ ${logLevel} -ge 2 ]; then
    log Error $*
  fi
}

function logWarning() {
  if [ ${logLevel} -ge 3 ]; then
    log Warning $*
  fi
}

function logInfo() {
  if [ ${logLevel} -ge 4 ]; then
    log Info $*
  fi
}

function logCmd() {
  if [ ${logLevel} -ge 5 ]; then
    log Command $*
  fi
}

function logDebug {
  if [ ${logLevel} -ge 5 ]; then
    log Debug $*
  fi
}

function log() {
  tag=$1
  shift
  echo "$(date) [${tag}]: $*"
}

function logTest() {
  setLogLevel info
  logError "log error test"
  logWarning "log warning test"
  logInfo "log info test"
  logCmd "log cmd test"
  logDebug "log debug test"
  setLogLevel aaa
}

